// src/data/overviewData.js
export const overviewData = [
    { title: "Total Balance", value: "$2,255", subText: "+6.4% from income" },
    { title: "Total Income", value: "$3,500", subText: "0 transactions this month" },
    { title: "Total Expenses", value: "$1,245", subText: "0 transactions this month" },
    { title: "Savings Rate", value: "64.4%", subText: "$2,250 saved so far" }
  ]
  