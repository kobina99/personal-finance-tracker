// src/data/transactions.js
export const transactions = [
    { description: "Monthly Salary", date: "6/1/2024", amount: 3500, type: "income" },
    { description: "Grocery Store", date: "6/5/2024", amount: 75, type: "expense" },
  ]
  